from django.shortcuts import render

from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
# from rest_framework.response import response
from rest_framework import status, viewsets
from . models import Employee
from . serializers import Employeeserializer

# class employeeList(APIView):

#     def get(self, request):
#         employee1= employee.objects.all()
#         serializer=employeeserializer(employee1, many=true)
#         return Response(serializer.data)


#     def post(self):
#         pass


